package Helpers;

import org.apache.log4j.Logger;


import functionLibrary.Utilities;
import functionLibrary.Waits;
import functionLibrary.actions;

public class OfferIdFrmURL_Helper extends CommonHelper {

	public OfferIdFrmURL_Helper(){
		Log = Logger.getLogger(OfferIdFrmURL_Helper.class.getName());
		waits = new Waits();
		util = new Utilities();
					
	}
	
	public String getOfferId() {
		String url = util.getURL();
		return url.substring(56);
		
	}
	
	
	
	
	
}
