package Helpers;

import java.net.HttpURLConnection;
import java.net.URL;
import org.apache.log4j.Logger;
import pageObjects.Home_POM;
import com.qb.initializer.InitialiserClass;
import functionLibrary.Utilities;

public class CommonHelper extends InitialiserClass {
	
	public CommonHelper(){
		Log = Logger.getLogger(CommonHelper.class.getName());
		home = new Home_POM();
		util = new Utilities();
	}
	
	public String getPageTitle(){
		return driver.getTitle();
	}
	public void verifyLinkActive(String linkUrl) throws Exception
	{
           URL url = new URL(linkUrl);
           HttpURLConnection httpURLConnect=(HttpURLConnection)url.openConnection();
           httpURLConnect.setConnectTimeout(3000);
           httpURLConnect.connect();
           System.out.println(httpURLConnect.getResponseCode());
           if(httpURLConnect.getResponseCode()==200)
           {
               System.out.println(linkUrl+" - "+httpURLConnect.getResponseMessage());
               Log.info(linkUrl+" - "+httpURLConnect.getResponseMessage());
            }
          if(httpURLConnect.getResponseCode()==HttpURLConnection.HTTP_NOT_FOUND)  
           {
               System.out.println(linkUrl+" - "+httpURLConnect.getResponseMessage() + " - "+ HttpURLConnection.HTTP_NOT_FOUND);
               Log.info(linkUrl+" - "+httpURLConnect.getResponseMessage() + " - "+ HttpURLConnection.HTTP_NOT_FOUND);
            }
        
	}
}
