package com.qb.initializer;

import org.apache.log4j.Logger;
import com.qb.driver.DriverClass;
import Helpers.CommonHelper;
import Helpers.OfferIdFrmURL_Helper;
import functionLibrary.Utilities;
import functionLibrary.Waits;
import pageObjects.Accounting_POM;
import pageObjects.Home_POM;
import pageObjects.Online_POM;
import pageObjects.PlansAndPricing_POM;
import pageObjects.SelfEmployed_POM;


public abstract class InitialiserClass extends DriverClass  {

	
	protected InitialiserClass(){		
		Log = Logger.getLogger(InitialiserClass.class.getName());
		util = new Utilities();
		waits = new Waits();
	}
	
	public Home_POM home;
	public PlansAndPricing_POM plansPricing;
	public Accounting_POM acctPricing;
	public Online_POM online;
	public SelfEmployed_POM selfEmployed;
	
	

	public CommonHelper commonHelper;
	public OfferIdFrmURL_Helper offerIdHelper;
	
	
	public Utilities util;
}
