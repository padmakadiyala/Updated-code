package com.qb.constants;

public class UtilConstants {

	static String currentDir = System.getProperty("user.dir");  //goes to current user directory eg:pkadiyala/Quickbooks/
	
	public static final String siteURI = "https://quickbooks.intuit.com/"; 
			
	public static final String pathDriverSheet = currentDir +"/dataSource/Driver_TestSheet.xlsx"; //
	
	public static final String pathDataSheet = currentDir +"/dataSource/DataSheet.xlsx";
	
	public static final String pathChromeDriver = currentDir + "/drivers/chromedriver"; //this is constant
	
	public static final String pathScreenShotsFolder = currentDir + "/Screens"; //Taking screenshots
	
	public static final String pathReports = currentDir + "/Reports";
	
	public static final String pathExtentConfigFile = currentDir+"/libs/extent-config.xml";
	
	public static final String pathOfferIdsSheet = currentDir +"/dataSource/OfferIds.xlsx"; 
		
	
}
