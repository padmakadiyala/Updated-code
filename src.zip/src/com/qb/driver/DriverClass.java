package com.qb.driver;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import functionLibrary.Utilities;
import functionLibrary.Waits;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Stopwatch;
import com.qb.constants.UtilConstants;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class DriverClass {

  public static String browser;
  public static WebDriver driver;
  public static WebDriverWait wait;
  public static Waits waits;
  public static Logger Log;
  public static Utilities util;
  public static ExtentReports extent;
  public static ExtentTest extentLogger;
 
  
	
public static void main(String[] args) throws Exception   { 
	  
	   extent = new ExtentReports(UtilConstants.pathReports+"/Report "+ Utilities.timeStampGenerator()+".html", true);
	   extentLogger = new ExtentTest("QuickBooks", "Test Automation");
	   extent.loadConfig(new File(UtilConstants.pathExtentConfigFile));
	   extentLogger = extent.startTest("Driver Class");
	   
	   Log = Logger.getLogger(DriverClass.class.getName());
	   DOMConfigurator.configure("log4j.xml");
       Log.addAppender(new FileAppender(new PatternLayout(),"log.txt", false));  

       Log.info("\n\n ********************************************************Initialize selenium********************************************************");
       Log.info(" ***********Starting Tests************ ");
     
      
       
       /* Local Variables*/
       int rowCount,sheetNum = 0;
       String outputFilePath = UtilConstants.pathDriverSheet;
       String function_tc;
       String package_name = "testScripts.";
       String class_name = null ,execute;
       String startTime,endTime = null;
       String duration = null,result = null;
       Stopwatch timer = Stopwatch.createUnstarted();
       driver = null;
       
   	/********************************************************************************************************************************************/
       
			  	browser = "chrome";

	/********************************************************************************************************************************************/
			  	
	  	//Utilities.killdrivers();
	  	Utilities.setExcelFile(outputFilePath,0);
	  			  	  	
       Utilities.setExcelFile(outputFilePath,sheetNum);
       rowCount = Utilities.getRowCount(sheetNum);
       System.out.println("Total No of test Cases : "+(rowCount-1)); 
       
       try{
    	   
       	for(int i=1;i<rowCount;i++){
    	                                   
         execute = Utilities.getCellData(i, 3).toUpperCase();
          if(execute.equalsIgnoreCase("Y")){
                                                                
             DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
             Date date = new Date();
             startTime = dateFormat.format(date);                                                       
             
             timer.reset();
             timer.start();
              
             driver = Utilities.webDriverInitialize(browser);
             driver.manage().window().maximize(); 
             driver.manage().deleteAllCookies();
             util = new Utilities();
             
             
             String TC = Utilities.getCellData(i, 1).trim();
             
             class_name = Utilities.getCellData(i, 1).trim();     
             class_name = package_name.concat(class_name);
             function_tc = Utilities.getCellData(i, 2).trim();
             
             System.out.println("########################  Executing Test Case: "+function_tc+" belonging to Story:"+class_name+" ########################");
             Log.info("########################  Executing Test Case: "+function_tc+" belonging to Story:"+class_name+" ########################");
             extentLogger = extent.startTest(TC+"_"+function_tc);
             extentLogger.log(LogStatus.INFO, "####################  Executing Test Case: "+TC+"_"+function_tc+" ####################");
             
             
         	  Utilities ut = new Utilities();
              
              ut.loadURL();
         
             
              //Reflection Class
        	  Class<?> thisClass = Class.forName(class_name);
        	  Constructor<?> constructor = thisClass.getConstructor(WebDriver.class);
        	  Object iClass = (Object)constructor.newInstance(driver);
              Method thisMethod = thisClass.getDeclaredMethod(function_tc);
              Object obj = thisMethod.invoke(iClass);
              result = obj.toString();
              
              
              if(result.equalsIgnoreCase("Fail")){
            	  String ssName = TC+"_"+function_tc+Utilities.timeStampGenerator();
            	  ut.getScreenShot(ssName);
            	  extentLogger.log(LogStatus.FAIL, "*************** Test case failed for: "+TC+"_"+function_tc+" ***************");
            	  extentLogger.log(LogStatus.FAIL,  extentLogger.addScreenCapture(UtilConstants.pathScreenShotsFolder+"/"+ssName+".jpg"));            	 
              }else{
            	  extentLogger.log(LogStatus.PASS, "*************** Test case passed for: "+TC+"_"+function_tc+" ***************");
              }
              extent.endTest(extentLogger);
    	      extent.flush();
              
              
              util.logoutSite();
                  
              timer.stop();            
              date = new Date();
              endTime = dateFormat.format(date);
              duration = Long.toString(timer.elapsed(TimeUnit.SECONDS));
              
              Utilities.setExcelFile(outputFilePath,sheetNum);
    	      ut.putCellData(outputFilePath, sheetNum, i, 4, startTime);
    	      ut.putCellData(outputFilePath, sheetNum, i, 5, endTime); 
    	      ut.putCellData(outputFilePath, sheetNum, i, 6, duration);  
    	      ut.putCellData(outputFilePath, sheetNum, i, 7, result);    	          	      
    	      
          }
          else  continue;
       	}      
       
       }catch (NoSuchMethodException e) {
    	   e.printStackTrace();
            System.out.println(e);
      } 
	}  

}
      
                                               