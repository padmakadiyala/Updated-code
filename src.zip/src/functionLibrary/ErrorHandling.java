package functionLibrary;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import com.qb.driver.DriverClass;

public class ErrorHandling extends Exception {

	
	private static final long serialVersionUID = 1L;

	/**
	 * List of exceptions handled:
	 * TimeoutException
	 * UnexpectedAlertPresentException
	 * ElementNotSelectableException
	 * ElementNotVisibleException
	 * ErrorInResponseException
	 * InvalidSelectorException
	 * InvalidSwitchToTargetException
	 * NoSuchElementException
	 * WebDriverException
	 * FileNotFoundException
	 */
	
	public static void handleExceptions(Exception e){
	
	Logger Log = Logger.getLogger(DriverClass.class.getName());
	DOMConfigurator.configure("log4j.xml");
	
	Log.info("############################# Exception Encountered #############################");
	
	String exceptionType =  e.getClass().toString().substring(6);
	
	Log.info("Screenshot for the application saved in the Screens folder");
	
	if(exceptionType.contains("TimeoutException")){
		System.out.println("Timeout Exception : Finding Element did not complete in enough time");
		Log.error("Timeout Exception : Finding An Element did not complete in enough time");
		Log.error(e.getMessage());
	}
	
	else if(exceptionType.contains("NoSuchMethodException")){
		System.out.println("NoSuchMethodException: The Test Script Name or the Use Case Name is incorrect.");
		Log.info("NoSuchMethodException: The Test Script Name or the Use Case Name is incorrect.");
		Log.error(e.getMessage());
	}
	
	else if(exceptionType.contains("UnexpectedAlertPresentException")){
		System.out.println("UnexpectedAlertPresent Exception : An unexpected alert appeared.");
		Log.error("UnexpectedAlertPresent Exception : An unexpected alert appeared.");
		Log.error(e.getMessage());
	}
	
	else if(exceptionType.contains("ElementNotSelectableException")){
		System.out.println("ElementNotSelectable Exception : The element is unselectable.");
		Log.error("ElementNotSelectable Exception : The element is unselectable.");
		Log.error(e.getMessage());
	}
	
	else if(exceptionType.contains("ElementNotVisibleException")){
		System.out.println("ElementNotVisible Exception : The  element is present on the DOM, but it is not visible, and so is not able to be interacted with.");
		Log.error("ElementNotVisible Exception : The  element is present on the DOM, but it is not visible, and so is not able to be interacted with.");
		Log.error(e.getMessage());
	}
	
	else if(exceptionType.contains("ErrorInResponseException")){
		System.out.println("ErrorInResponse Exception : An error while communicating with the firefox extension or the remote driver server.");
		Log.error("ErrorInResponse Exception : An error while communicating with the firefox extension or the remote driver server.");
		Log.error(e.getMessage());
		}
	
	else if(exceptionType.contains("InvalidSelectorException")){
		System.out.println("InvalidSelector Exception : The selector which is used to find an element does not return a WebElement. This happens when the selector is an xpath expression and it is either syntactically invalid (i.e. it is not a xpath expression) or the expression does not select WebElements");
		Log.error("InvalidSelector Exception : the selector which is used to find an element does not return a WebElement. This happens when the selector is an xpath expression and it is either syntactically invalid (i.e. it is not a xpath expression) or the expression does not select WebElements");
		Log.error(e.getMessage());
		}
	
	else if(exceptionType.contains("InvalidSwitchToTargetException")){
		System.out.println("InvalidSwitchToTarget Exception :  The frame or window target to be switched doesn�t exist.");
		Log.error("InvalidSwitchToTarget Exception :  The frame or window target to be switched doesn�t exist.");
		Log.error(e.getMessage());
	}
	
	else if(exceptionType.contains("NoSuchElementException")){
		System.out.println("NoSuchElement Exception : The element could not be found. Check the selector used for the function");
		Log.error("NoSuchElement Exception : The element could not be found. Check the selector used for the function");
		Log.error(e.getMessage());
	}
	
	else if(exceptionType.contains("WebDriverException")){
		System.out.println("WebDriver Exception : Basic WebDriver exception, check StackTrace on eclipse console.");
		Log.error("WebDriver Exception : Basic WebDriver exception, check StackTrace on eclipse console.");
		Log.error(e.getMessage());
	}
	
	else if(exceptionType.contains("FileNotFoundException")){
		System.out.println("FileNotFound Exception : The Excel file path was wrong, or the file has been deleted. Check the file location.");
		Log.error("FileNotFound Exception : The Excel file path was wrong, or the file has been deleted. Check the file location.");
		Log.error(e.getMessage());
	}
		
	else{
		Log.error("Java Exception");
		Log.error(e.getMessage());
	}
	e.printStackTrace();
		
}
			
	public static void handleAssertionError(AssertionError e){

		Logger Log = Logger.getLogger(DriverClass.class.getName());
		DOMConfigurator.configure("log4j.xml");
		Log.info("Screenshot for the application saved in the Screens folder");
		Log.error("Assertion Failed : The checkpoint placed in the script has failed.");
		Log.error(e.getMessage());
		System.out.println(e.getMessage());
		e.printStackTrace();
		
	}
	
}
