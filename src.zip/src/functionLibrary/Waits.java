package functionLibrary;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qb.driver.DriverClass;

public class Waits extends DriverClass {

	WebDriverWait wait;
	/* Constructors */
	 public Waits(){
		 wait = new WebDriverWait(driver,30);
    }
	
	
		 /**
		   * @param waitTime
		   */
		  public void setWaitTimeInSeconds(int waitTime) {
		    wait = new WebDriverWait(driver, waitTime);
		  }

		  public boolean waitUntilVisibilityOfElementLocated(WebElement element) {
		    try {
		      waitForVisibleElement(element);
		      return true;
		    }
		    catch (TimeoutException e) {
		      return false;
		    }
		    catch (IllegalStateException e) {
		      return false;
		    }
		  }

		  /**
		   * Method waiting until the element is either invisible or not present on the DOM
		   */
		  public boolean waitUntilInvisibilityOfElementLocated(By locator) {
		    return wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
		  }
		  
		  public boolean waitUntilInvisibilityOfElementLocated(WebElement xpath) {
			    return wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(xpath.toString())));
			  }
		  

		
		 public void waitAndClick(WebElement element) {
		 
		 waitForVisibleElement(element);
		 wait.until(ExpectedConditions.elementToBeClickable(element));
		 ((JavascriptExecutor) driver).executeScript(
                 "arguments[0].scrollIntoView(true);", element);
		Capabilities cp = ((RemoteWebDriver) driver).getCapabilities();
             if (cp.getBrowserName().equals("chrome")) {
                 try {
                       ((JavascriptExecutor) driver).executeScript(
                             "arguments[0].click();", element);
                 } catch (Exception e) {
                	 System.out.println("Can't click on the element");
                 }
             }
			   
             else if (cp.getBrowserName().equals("internet explorer")) {
                 try {
                    ((JavascriptExecutor) driver).executeScript(
                             "arguments[0].click();", element);
                 } catch (Exception e) {
                	 System.out.println("Can't click on the element");
                 }
             }
             else if (cp.getBrowserName().equals("firefox")) {
                           element.click();
             }
		  }
		
		
		public WebElement waitForClickableElement(WebElement element) {
			 
			    if (element != null) {
			    	Log.debug("Waiting for Element to be clickable, Element : " + element);
			      try {
			      return wait.until(ExpectedConditions.elementToBeClickable(element));
			      }
			      catch (TimeoutException e) {
			    	  Log.fatal("Element not clickable after wait, Element: " + element);
			      }
			    }
			    return null;
			  }
	
		 
		public WebElement waitForVisibleElement(WebElement element) {
			 
			    if (element != null) {
			    	Log.debug("Waiting for Visible Element, Element : " + element);
			      try {
			      return wait.until(ExpectedConditions.visibilityOf(element));
			      }
			      catch (TimeoutException e) {
			    	  Log.fatal("Element not visible after wait, Element: " + element);
			      }
			    }
			    return null;
			  }

		  
			  public WebElement waitForVisibleElement(By by) {
			    if (by != null) {
			    	Log.debug("Waiting for Visible Element, By : " + by);
			      try {
			        return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			      }
			      catch (TimeoutException e) {
			    	 Log.fatal("Element not visible after wait, By: " + by);
			      }
			    }
			    return null;
			  }

			  public  void waitForSpinner() {
			    waitUntilInvisibilityOfElementLocated(By.cssSelector("div[class='mini-loader']"));
			    Log.info("Waiting for spinner to disappear");
			  }
		
		  public void hardWait(int seconds) throws InterruptedException {
			  Thread.sleep(seconds*1000);				  
		  }
}			  
