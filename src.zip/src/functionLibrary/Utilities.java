package functionLibrary;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.qb.constants.UtilConstants;
import com.qb.driver.DriverClass;

public class Utilities extends DriverClass {

	
	private static XSSFSheet ExcelWSheet;
    private static XSSFWorkbook ExcelWBook;
    private static XSSFCell Cell;
	
	/* Constructors */
	public Utilities(){
    	Log = Logger.getLogger(Utilities.class.getName());
	}
	    
    /*This method manages Hovering and clicking on the menu items for the Navigation of the site */  
    public void navigateHover(WebElement mainMenu,WebElement subMenu) {
    	waits.waitForClickableElement(mainMenu);
    	Actions actions = new Actions(driver);
    	actions.moveToElement(mainMenu).build().perform();
    	JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].click();",subMenu);
	
    }
        
    /* Loading the URL of the application */
    
    public void loadURL(){
    	driver.get(UtilConstants.siteURI);
    	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    	//driver.findElement(By.xpath("//*[@id='geo-ip-redirect-popup']/div/a[1]")).click();
    	Log.info("Clicked on Visit US Site Link");
    	
    }
     
    
    /* Initialize the type of browser required */
        
    public static WebDriver webDriverInitialize(String browser) throws Exception{	
    	//killdrivers(); // if any background drivers are there it will close
		 WebDriver driver;
		 switch (browser)
	        {
	            case "chrome":
	            	File file = new File(UtilConstants.pathChromeDriver);
	        		System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
	                driver = new ChromeDriver();
	                break;
	            case "firefox":
	                driver = new FirefoxDriver();
	                break;
	          
	            default:
	            	 driver = new FirefoxDriver();
		            break;
	        }
 		return driver;
    }
    
       
    
	/**
	 *  This method is to set the File path and to open the Excel file, 
	 * Pass Excel Path and Sheet Number as Arguments to this method
	 */
  
	public static void setExcelFile(String Path,int sheet)  {
         try {
	          FileInputStream ExcelFile = new FileInputStream(Path); // To load the file
	          ExcelWBook = new XSSFWorkbook(ExcelFile);
	          ExcelWSheet = ExcelWBook.getSheetAt(sheet);
          } catch (Exception e){
        	  ErrorHandling.handleExceptions(e);
        	  e.printStackTrace();
          }
	}
	  
	/** 
	 * This method is to read the test data from the Excel cell 
	 * Parameters as Row and Column Numbers
	 */
	
	public static String getCellData(int RowNum, int ColNum) throws Exception{
         try{	        	   	  
            Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
            String CellData = Cell.getStringCellValue();
            return CellData.toString();
         }catch (Exception e){
        	return "error in returning cell data";
        }
	  }

	/** 
	 * This method is to get the row count used of the excel sheet 
	 */
	
	public static int getRowCount(int sheet){
	        ExcelWSheet = ExcelWBook.getSheetAt(sheet);  
	        int number=ExcelWSheet.getLastRowNum()+1;
	        return number;
	    }
	  
	/**
	 * This method is to write the test data to the Excel sheet in the specified cell 
	 */
	
	public void putCellData(String filePath,int sheetNo,int RowNum, int ColNum, String Value) throws Exception{
	    
		try{
	       ExcelWSheet = ExcelWBook.getSheetAt(sheetNo); 
	       Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
	       Cell.setCellValue(Value);
	       FileOutputStream out = new FileOutputStream(new File(filePath));     
	       ExcelWBook.write(out);
	       out.flush();
		   out.close();
	    }catch (Exception e){
	       Log.error("Error in Putting cell data!! Please close driver sheet and try running....");
	       System.out.println("Error in Putting cell data!! Please close driver sheet and try running....");
    	   e.printStackTrace();
       }
    }
	
	
	
	public boolean VisibilityOfElement(WebElement element) {
	    try {
	    	wait = new WebDriverWait(driver,4);
	        (wait).until(ExpectedConditions.visibilityOf(element));
	        wait = new WebDriverWait(driver,4);
	    } catch (NoSuchElementException | TimeoutException e) {
	    	wait = new WebDriverWait(driver,4);
	        return false;
	    }
	    return true;
	}
	
	 public void logoutSite(){ 	
		    	driver.quit();
	    }
    
	/**
	 * This method generates the current timeStamp
	 */
	
	public static String timeStampGenerator()	{
		
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd-hhmmss");
		Date date1 = new Date();
		String timestamp = dateFormat.format(date1);
		return timestamp;
		
	}	
	/**
	 *  Kills the unnecessary processes of IEDriverServer and ChromeDriver      
	 */
	
	public static void killdrivers() throws IOException, InterruptedException{
		//Runtime rt = Runtime.getRuntime();
		//rt.exec("taskkill /F /IM chromedriver /T"); 
		driver.quit();
		Thread.sleep(2000);
	}	
		
   /**
	*  returns an element based on locator
	*/
   public WebElement getElement(By by) {
	   wait = new WebDriverWait(driver,20);
	   wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	   return driver.findElement(by);
	   
   }
	
   	/**
	  * This Method will Hover and return the Text
	  * @param element
	  */
	 public String hoverAndgetText(WebElement element){
		 wait = new WebDriverWait(driver,8);
		 Actions actions = new Actions(driver);
		 actions.moveToElement(element).build().perform();
		 return element.getText();
	 }
	 
 	/**
 	 * This method takes the screenshot of the webPage
	 */
	
	public void getScreenShot(String fileName) throws IOException{
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File(UtilConstants.pathScreenShotsFolder+"/"+fileName+".jpg"));
	}
	
	/*
	 * Returns the current page title*/
	public  String getPageTitle(){
		return driver.getTitle();
	}
	
	
	public String getURL() {
		return driver.getCurrentUrl();
	}

}   
   
