package functionLibrary;


import java.util.ArrayList;
import java.util.Set;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.qb.initializer.InitialiserClass;


public class actions extends InitialiserClass {
	
	/* Constructors */
	public actions(){
    	Log = Logger.getLogger(actions.class.getName());

	}
		
	 /**
	  * Waits for the elements and enters text into it
	  * @param element
	  * @param value
	  */	
	 public static void waitAndType(WebElement element, String value){
		 waits.waitForVisibleElement(element);
		 element.sendKeys(value);
		 printLogs(element, value);
	   }
		 
	 /**
	  * Waits for the elements to be in clickable state and then clicks it.
	  * @param element
	  */	 
	 public static void waitAndClick(WebElement element){		   
		 waits.waitForClickableElement(element);
		 printLogs(element, "");
		 element.click();
		    	   
	   }
	 
	 /**
	  * This Method is used to Screen scroll to bottom.
	  * */
	 public static void scrollToBottom(){
		 ((JavascriptExecutor) driver)
            .executeScript("window.scrollTo(0,Math.max(document.documentElement.scrollHeight,"
            		+ "document.body.scrollHeight,document.documentElement.clientHeight));");
		 Log.info("Screen scrolled down to the Bottom");
	 }
	 
	 /**
	  * This Method is used for scroll to given WebElement
	  * @param element
	  * */
	 public static void scrollTo(WebElement element) {
	        ((JavascriptExecutor) driver).executeScript(
	                "arguments[0].scrollIntoView();", element);
	        Log.info("Page scrolled to the element.Element: "+element);
	 }
	 
	 /**
	  * This Method is used for scroll to given WebElement
	  * @param element
	  * @throws Exception 
	  * */
	 public static void scrollAndClick(WebElement element) throws Exception {
		 waits.waitForClickableElement(element);
		 printLogs(element, "");
	        ((JavascriptExecutor) driver).executeScript(
	                "arguments[0].scrollIntoView();", element);
	        javascriptClick(element);
	 }
		 
	 /**
	  * The Below Method is for Java click instead of Selenium Click
	  * @param element
	  * */
	 		
	 public static void javascriptClick(WebElement element) throws Exception{
		
		 Thread.sleep(1000);
		 printLogs(element, "");
		 JavascriptExecutor js = (JavascriptExecutor)driver;
		 js.executeScript("arguments[0].click();",element);
		
		}
		
	 /**
	  * Clears the text field and then enters text into it
	  * @param element
	  * @param value
	  */
	 public static void clearAndType(WebElement element, String value){
		   
		    //waits.waitForVisibleElement(element);
		    element.clear();
		    element.sendKeys(value);
		    printLogs(element, value);


	   }
	 
	 /**
	  * This Method is used to Hover on WebElement
	  * @param element
	  * */
	 public static void hoverElement(WebElement e){
		 waits.waitForVisibleElement(e);
		 Actions actions = new Actions(driver);
		 actions.moveToElement(e).build().perform();
	 }	 
	
	
	 public static void selectValue(WebElement element, String value){
		   
			 waits.waitForVisibleElement(element);
			 Select dropDown = new Select(element);
			 Log.info("Value: "+value+" selected for the dropdown element.Element: "+element.getAttribute("name"));
		  try{	 
			  
			 dropDown.selectByVisibleText(value);
		 }catch(Exception e){	
			 Log.info("Value: "+value+" selected for the dropdown element.Element: "+element.getAttribute("name"));
			 dropDown.selectByValue(value);
		 	}		  
		 
	   }
	 		 
	 /**
	  * Verifies whether the actual message is the expected message
	  * @param expected
	  * @param actual
	  */
	 public static void verificationPoint(String expected,String actual){
		 
		 try{				 
			 Assert.assertEquals(expected, actual);
			 Log.info("Verification Point Passed for the text : "+expected);
		 }catch(Exception e){
			 
			 Log.error("The verification point has failed. Expected message was: "+expected+" but actual message is: "+actual);
		 }
	 }
	 
	 public static  void navigateBack() {
		 driver.navigate().back();
	 }
	 
	 public static void refreshPage() {
		 driver.navigate().refresh();
	 }
	 
	
	 public static void verificationPoint(String expected,WebElement element){
		 
		 try{	
			 waits.waitForVisibleElement(element);
			 Assert.assertEquals(expected, element.getText());
			 Log.info("Verification Point Passed for the text : "+expected);
		 }catch(Exception e){
			 
			 Log.error("The verification point has failed. Expected message was: "+expected+" but actual message is: "+element.getText()); 
		 }
	 }
	 
	 public static void windowTab(int index){

		 ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		 driver.switchTo().window(tabs.get(index));

		 } 
	 /* Window Handles Using Set */
	 public static void windowHandles() {
		 String mainWindow = driver.getWindowHandle();
		 System.out.println("Main Window handle is"+mainWindow);
		 Set<String> allWindows = driver.getWindowHandles();
		 System.out.println("Get all Windows size is: "+ allWindows);
		 
		 for(String currentWindow : allWindows) {
			 System.out.println("Current Window is:"+ currentWindow);
			 if(mainWindow.equals(currentWindow)) {
				 System.out.println("No action needed for MainWindow");
			 }
			 else {
				 driver.switchTo().window(currentWindow);
				 driver.close();
				 
			 }
		 }
		 
	 }
	 
	 /**
	  * Below Method Prints all Logs.
	  * */
	 public static void printLogs(WebElement element,String value){
			
		 if(element.getTagName().equals("input")){
			 Log.info("Text value: "+value+" entered in element., Element: "+element.getAttribute("name"));
		 }else if(element.getTagName().equals("a")){
			 if(element.getText().isEmpty() || element.getText().equalsIgnoreCase(null)){
				 Log.info("Clicked the link for Element :"+element.getAttribute("href"));}
			 else{
				 Log.info("Clicked the link for Element :"+element.getText());}
		 }else if(element.getTagName().equals("button")){
			 Log.info("Clicked the Button for Element :"+element.getText());
		 }else if(element.getTagName().equals("select")){
			 Log.info("Value: "+value+" selected for the dropdown element.Element: "+element.getAttribute("name"));
		 }else if(element.getAttribute("class").contains("button")){
			 if(element.getAttribute("name").equals(null)){
			     Log.info("Clicked the button for Element: "+element.getText()); }
			 else{
			     Log.info("Clicked the button for Element: "+element.getAttribute("name"));	}
		 }else if(element.getTagName().contains("img")){
			 Log.info("Clicked the image for Element: "+element.getAttribute("class"));	
		 	}

	 }
}
	 