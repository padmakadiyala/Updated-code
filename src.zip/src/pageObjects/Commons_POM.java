package pageObjects;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;

import com.qb.driver.DriverClass;

public class Commons_POM extends DriverClass{

	
	public Commons_POM() {
		ElementLocatorFactory locatorWait = new AjaxElementLocatorFactory(driver, 45);  
		PageFactory.initElements(locatorWait, this);
	}
	@FindBy(id="email")
	private WebElement newEmail;
	public WebElement getnewEmail(){
		return newEmail;
	}
	
	@FindBy(id="password")
	private WebElement newPassword;
	public WebElement getnewPassword(){
		return newPassword;
	}
	@FindBy(css="div[class='cart-buttons'] button[id='submit']")
	private WebElement Btn_placeOrder;
	public WebElement getBtn_placeOrder(){
		return Btn_placeOrder;
	}
	@FindBy(css="#submit")
	private WebElement Btn_submit;
	public WebElement getBtn_submit(){
		return Btn_submit;
	}
	@FindBy(xpath="//*[@id='main']/div/section[1]/h1")
	private WebElement Txt_ThanksSignUp;
	public WebElement getTxt_ThanksSignUp(){
		return Txt_ThanksSignUp;
	}
	
	@FindBy(css="#accept-cookie")
	private WebElement acceptCookie;
	public WebElement getacceptCookie(){
		return acceptCookie;
	}
	@FindBy(xpath="//h1")
	private WebElement h1;
	public WebElement geth1(){
		return h1;
	}
}
