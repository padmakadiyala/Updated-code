package pageObjects;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;

public class Home_POM extends Commons_POM {
	
	public Home_POM(){	    	 
        ElementLocatorFactory locatorWait = new AjaxElementLocatorFactory(driver,40);
        
        //This initElements method will create all WebElements
        PageFactory.initElements(locatorWait, this);
		}	
	
		 @FindBy(xpath="//section[@class='menus menus-left hidden-sm hidden-xs']//a[@class='submenu-header-link'][contains(text(),'Plans & Pricing')]")
	     private WebElement plansAndPricing;
	     public WebElement getplansAndPricing(){
	     	return plansAndPricing;
	     }
	     @FindBy(xpath="//*[@id='geo-ip-redirect-popup']/div/a[1]")
	     private WebElement LnkVisitUSSite;
	     public WebElement getLnkVisitUSSite(){
	     	return LnkVisitUSSite;
	     }
	     
	   
	     
	    
	  }
