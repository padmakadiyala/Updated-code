package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;

public class PlansAndPricing_POM extends Commons_POM {

	public PlansAndPricing_POM() {
		ElementLocatorFactory locatorWait = new AjaxElementLocatorFactory(driver, 30);
		PageFactory.initElements(locatorWait, this);
	}

	@FindBy(xpath = "//a[@data-object-detail='Simple Start']")
	private WebElement BuyNow_simpleStart;
	public WebElement getBuyNow_simpleStart() {
		return BuyNow_simpleStart;
	}

	@FindBy(xpath = "//a[@data-object-detail='Essentials']")
	private WebElement BuyNow_Essentials;
	public WebElement getBuyNow_Essentials() {
		return BuyNow_Essentials;
	}

	@FindBy(xpath = "//a[@data-object-detail='Plus']")
	private WebElement BuyNow_Plus;
	public WebElement getBuyNow_Plus() {
		return BuyNow_Plus;
	}

	@FindBy(xpath = "//a[@data-object-detail='Advanced']")
	private WebElement BuyNow_Advanced;
	public WebElement getBuyNow_Advanced() {
		return BuyNow_Advanced;
	}

	
	// Code for Freetrial page Begins here

	/* FreeTrialtoggle element */
	@FindBy(xpath = "//div[@class='_toggleButton']")
	private WebElement FreeTrial_Toggle;
	public WebElement FreeTrial_toggle() {
		return FreeTrial_Toggle;
	}

	// Code for Plans and Pricing link under Main Menu
	 
	@FindBy(xpath = "//section[@class='menus menus-left hidden-sm hidden-xs']//a[@class='submenu-header-link'][contains(text(),'Plans & Pricing')]")
	private WebElement Plansnpricing_Link;
	public WebElement getPlansnpricing_Link() {
		return Plansnpricing_Link;
	}

	@FindBy(xpath = "//div[@class='tryit-free-link-url default-product']//a[@data-object-detail='Simple Start']")
	private WebElement FreeTrial_SimpleStart;
	public WebElement getFreeTrial_SimpleStart() {
		return FreeTrial_SimpleStart;
	}

	@FindBy(xpath = "//div[@class='tryit-free-link-url default-product']//a[@data-object-detail='Essentials']")
	private WebElement FreeTrial_Essentials;
	public WebElement getFreeTrial_Essentials() {
		return FreeTrial_Essentials;
	}

	@FindBy(xpath = "//div[@class='tryit-free-link-url default-product']//a[@data-object-detail='Plus']")
	private WebElement FreeTrial_Plus;
	public WebElement getFreeTrial_Plus() {
		return FreeTrial_Plus;
	}

	@FindBy(xpath = "//div[@class='tryit-free-link-url ']//a[@data-object-detail='Self Employed']")
	private WebElement FreeTrial_SelfEmployed;
	public WebElement getFreeTrial_SelfEmployed() {
		return FreeTrial_SelfEmployed;
	}

}
