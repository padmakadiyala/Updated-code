package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;

public class SelfEmployed_POM extends Commons_POM{

	public SelfEmployed_POM(){
		ElementLocatorFactory locatorWait = new AjaxElementLocatorFactory(driver, 30);
		PageFactory.initElements(locatorWait, this);
	}
	
	//Self Employed Container xpath for CTA
		@FindBy(xpath="//div[@data-product='QuickBooks Self-Employed']//a[contains(@id,'buynow-url')]")
		private WebElement BuyNow_SelfEmployed;
		public WebElement getBuyNow_SelfEmployed(){
			return BuyNow_SelfEmployed;
		}
}
