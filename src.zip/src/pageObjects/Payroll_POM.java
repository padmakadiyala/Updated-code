package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;

public class Payroll_POM extends Commons_POM {

	public Payroll_POM() {
		ElementLocatorFactory locatorWait = new AjaxElementLocatorFactory(driver, 30);
		PageFactory.initElements(locatorWait, this);
	}

	// Buy now CTA
	@FindBy(xpath = "//div[@class='buttons']//a[@data-di-id='#heroCTA_buynow']")
	private WebElement Btn_buynow;
	public WebElement getBtn_buynow() {
		return Btn_buynow;
	}

	// Core Buynow CTA
	@FindBy(xpath = "//div[@data-product='Payroll Core']//a[@data-di-id='#CTA_buyNow_core']")
	private WebElement Btn_buynowcore;
	public WebElement getBtn_buynowcore() {
		return Btn_buynowcore;
	}

	// Plus Buynow CTA
	@FindBy(xpath = "//div[@data-product='Payroll Core Add-on 3']//a[@id='buynow-url-1860']")
	private WebElement Btn_buynowplus;
	public WebElement getBtn_buynowplus() {
		return Btn_buynowplus;
	}

	// Simple start Buynow CTA
	@FindBy(xpath = "//div[@data-product='Payroll Core Add-on 1']//a[@data-di-id='#CTA_buyNow_premium']")
	private WebElement Btn_buynowsimplestart;
	public WebElement getBtn_buynowsimplestart() {
		return Btn_buynowsimplestart;
	}

	/* Payroll Premium CTA's Start here */
	@FindBy(xpath = "//div[@data-product='Payroll Premium']//a[@data-di-id='#CTA_core_buynow']")
	private WebElement Btn_buynowpremium;
	public WebElement getBtn_buynowpremium() {
		return Btn_buynowpremium;
	}

	@FindBy(xpath = "//div[@data-product='Payroll Premium Add-on 1']//a[@data-di-id='#CTA_premium_buynow']")
	private WebElement Btn_buynowpremiumss;
	public WebElement getBtn_buynowpremiumss() {
		return Btn_buynowpremiumss;
	}

	@FindBy(xpath = "//div[@data-product='Payroll Premium Add-on 3']//a[@data-di-id='#CTA_elite_buynow']")
	private WebElement Btn_buynowpremplus;
	public WebElement getBtn_buynowpremplus() {
		return Btn_buynowpremplus;
	}

	/* Payroll Elite CTA's */
	@FindBy(xpath = "//div[@data-product='Payroll Elite']//a[@data-di-id='#CTA_buyNow_core']")
	private WebElement Btn_buynowelite;
	public WebElement getBtn_buynowelite() {
		return Btn_buynowelite;
	}

	@FindBy(xpath = "//div[@data-product='Payroll Elite Add-on 1']//a[@data-di-id='#CTA_buyNow_premium']")
	private WebElement Btn_buynowelitess;
	public WebElement getBtn_buynowelitess() {
		return Btn_buynowelitess;
	}

	@FindBy(xpath = "//div[@data-product='Payroll Elite Add-on 3']//a[@id='buynow-url-4742']")
	private WebElement Btn_buynoweliteplus;
	public WebElement getBtn_buynoweliteplus() {
		return Btn_buynoweliteplus;
	}

	/* Payroll learn */
	@FindBy(xpath = "//div[@data-product='Payroll Elite']//a[@data-di-id='#CTA_buyNow_elite']")
	private WebElement Btn_buynowlearnelite;
	public WebElement getBtn_buynowlearnelite() {
		return Btn_buynowlearnelite;
	}

	@FindBy(xpath = "//div[@data-product='Payroll Premium']//a[@data-di-id='#CTA_buyNow_premium']")
	private WebElement Btn_buynowlearnprem;
	public WebElement getBtn_buynowlearnprem() {
		return Btn_buynowlearnprem;
	}

	/* Payroll desktop CTA's */
	@FindBy(xpath = "//div[@class='chart-component sku_class chart-component--variant--3-sku']//a[@data-di-id='#CTA_basicpayroll_try']")
	private WebElement Btn_buynowdesktopbasic;
	public WebElement getBtn_buynowdesktopbasic() {
		return Btn_buynowdesktopbasic;
	}

	@FindBy(xpath = "//div[@class='chart-component sku_class chart-component--variant--3-sku']//a[@data-di-id='#CTA_assistedpayroll_contactus']")
	private WebElement Btn_buynowdesktopassisted;
	public WebElement getBtn_buynowdesktopassisted() {
		return Btn_buynowdesktopassisted;
	}

	@FindBy(xpath = "//div[@class='chart-component sku_class chart-component--variant--3-sku']//a[@data-di-id='#CTA_enhancedpayroll_try']")
	private WebElement Btn_buynowdesktopenhanced;
	public WebElement getBtn_buynowdesktopenhanced() {
		return Btn_buynowdesktopenhanced;
	}

	/* desktop/basic CTA's */
	@FindBy(xpath = "//a[@id='buynow-url-1197']")
	private WebElement Btn_buynowdesktopannual;
	public WebElement getBtn_buynowdesktopannual() {
		return Btn_buynowdesktopannual;
	}

	@FindBy(xpath = "//a[@id='buynow-url-9672']")
	private WebElement Btn_buynowdesktopmonthly;
	public WebElement getBtn_buynowdesktopmonthly() {
		return Btn_buynowdesktopmonthly;
	}

	/* dektop Enhanced */
	@FindBy(xpath = "//a[@id='buynow-url-9672']")
	private WebElement Btn_buynowdesktopenhanannual;
	public WebElement getBtn_buynowdesktopenhanannual() {
		return Btn_buynowdesktopenhanannual;
	}

	@FindBy(xpath = "//a[@id='buynow-url-7856']")
	private WebElement Btn_buynowdesktopenhanmonthly;
	public WebElement getBtn_buynowdesktopenhanmonthly() {
		return Btn_buynowdesktopenhanmonthly;
	}

	/* Enhanced Try now CTA */
	@FindBy(xpath = "//a[contains(@class,'base-button jumbo-button')]")
	private WebElement Btn_Trynow;
	public WebElement getBtn_Trynow() {
		return Btn_Trynow;
	}

}
