package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;

public class TSheets_POM extends Commons_POM{
	
	
	public TSheets_POM(){
		ElementLocatorFactory locatorWait = new AjaxElementLocatorFactory(driver, 30);
		PageFactory.initElements(locatorWait, this);
	}
	
	@FindBy(xpath="//div[@class='buttons']//a[@data-di-id='#signup']")
	private WebElement Btn_tryitfree;
    public WebElement getBtn_tryitfree(){
    	return Btn_tryitfree;
    }
	
	

}

