package pageObjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement; 
import org.openqa.selenium.support.FindBy; 
import org.openqa.selenium.support.PageFactory;  
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;

import functionLibrary.Waits;

public class LoginPage {

			/**      
	     * * All WebElements are identified by @FindBy annotation      */   
	    WebDriver driver;     
	    
	    /* The below web elements cater to the Login screen:*/
	    
	    @FindBy(css="#accept-cookie")
        private WebElement acceptCookies;
        public WebElement getaccceptCookies(){
        	return acceptCookies;
        }
	    
	    @FindBy(xpath="//li[@class='login-button']/a")
	    private WebElement Lnk_Login;
	    public WebElement getLnk_Login(){
	    	return Lnk_Login;
	    }
	      
	    @FindBy(id="email2")    
	    private WebElement txt_emailId;          
	    public WebElement gettxt_emailId() {
			return txt_emailId;
		}
		
	    @FindBy(id="password2")
	    private WebElement txt_Password;
	    public WebElement getTxt_Password() {
			return txt_Password;
		}
	    
	 
	   // @FindBys({@FindBy(xpath="//*[@name='loginForm']"),@FindBy(xpath="//button[@type='submit']")})
	    @FindBy(xpath="//*[text()='Sign In']")
	    private WebElement btn_SignIn ;
		   public WebElement getBtn_SignIn() {
				return btn_SignIn;
			}
		   
	    @FindBy(css="li[class='fun'] img")	    
	    private WebElement lnk_userDropdown;	    
	    public WebElement getLnk_userDropdown() {
			return lnk_userDropdown;
		}

	    @FindBy(css="#headerLogOut")
	    private WebElement lnk_Logout;	    
		public WebElement getLnk_Logout() {
			return lnk_Logout;
		}

		public LoginPage(WebDriver driver){	    	 
	        this.driver = driver;	
	        ElementLocatorFactory locatorWait = new AjaxElementLocatorFactory(driver, 30);
	        
	        //This initElements method will create all WebElements
	        PageFactory.initElements(locatorWait, this);
	    }
	 
		public void loginUser(String email,String pwd){
	    	
	    	this.getaccceptCookies().click();
	    	this.getLnk_Login().click();
	       		    	
	    	this.txt_emailId.sendKeys(email);
	    	this.txt_Password.sendKeys(pwd);
	    	this.btn_SignIn.click();
	    	Waits wait = new Waits();
	    	wait.waitUntilInvisibilityOfElementLocated(By.xpath("//div[@class='mini-loader-wrap login-loader']"));

	    }

	    
}