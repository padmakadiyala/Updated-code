package pageObjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;

public class Online_POM extends Commons_POM {

	public Online_POM() {
		ElementLocatorFactory locatorWait = new AjaxElementLocatorFactory(driver, 30);
		PageFactory.initElements(locatorWait, this);
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Online Simple Start']//a[@data-di-id='#ssbuynow-c']")
	private WebElement Btn_onlineSimple;

	public WebElement getBtn_onlineSimple() {
		return Btn_onlineSimple;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Online Simple Start']//a[@data-di-id='#ssbuynow-c']")
	private WebElement Btn_onlineEssentials;

	public WebElement getBtn_onlineEssentials() {
		return Btn_onlineEssentials;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Online Plus']//a[@data-di-id='#plbuynow-c']")
	private WebElement Btn_onlinePlus;

	public WebElement getBtn_onlinePlus() {
		return Btn_onlinePlus;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Advanced']//a[@data-di-id='#advbuynow-c']")
	private WebElement Btn_onlineAdvanced;

	public WebElement getBtn_onlineAdvanced() {
		return Btn_onlineAdvanced;
	}

	/* Payroll Core Toggle Code */
	@FindBy(xpath = "//div[@data-wa-link='ss_core-toggle']")
	private WebElement Toggle_payrollCore;

	public WebElement getToggle_payrollCore() {
		return Toggle_payrollCore;
	}

	/* Payroll Premium Toggle Code */
	@FindBy(xpath = "//div[@data-wa-link='ss_prem-toggle']")
	private WebElement Toggle_payrollPremium;

	public WebElement getToggle_payrollPremium() {
		return Toggle_payrollPremium;
	}

	/* Payroll Elite Toggle Code */
	@FindBy(xpath = "//div[@data-wa-link='ss_elite-toggle']")
	private WebElement Toggle_payrollElite;

	public WebElement getToggle_payrollElite() {
		return Toggle_payrollElite;
	}

	/* Buy now CTA's after enabling toggle */
	@FindBy(xpath = "//div[@data-product='QuickBooks Online Simple Start']//a[@data-di-id='#ssbuynow_core']")
	private WebElement Btn_TsimpleStart;

	public WebElement getBtn_TsimpleStart() {
		return Btn_TsimpleStart;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Online Essentials']//a[@data-di-id='#esbuynow_core']")
	private WebElement Btn_Tessentials;

	public WebElement getBtn_Tessentials() {
		return Btn_Tessentials;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Online Plus']//a[@data-di-id='#plbuynow_core']")
	private WebElement Btn_TPlus;

	public WebElement getBtn_TPlus() {
		return Btn_TPlus;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Advanced']//a[@data-di-id='#advbuynow_core']")
	private WebElement Btn_TAdvanced;

	public WebElement getBtn_TAdvanced() {
		return Btn_TAdvanced;
	}

	/* Premium CTA's code */
	@FindBy(xpath = "//div[@data-product='QuickBooks Online Simple Start']//a[@data-di-id='#ssbuynow_prem']")
	private WebElement Btn_PremsimpleStart;

	public WebElement getBtn_PremsimpleStart() {
		return Btn_PremsimpleStart;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Online Essentials']//a[@data-di-id='#esbuynow_prem']")
	private WebElement Btn_Premessentials;

	public WebElement getBtn_Premessentials() {
		return Btn_Premessentials;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Online Plus']//a[@data-di-id='#plbuynow_prem']")
	private WebElement Btn_PremPlus;

	public WebElement getBtn_PremPlus() {
		return Btn_PremPlus;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Advanced']//a[@data-di-id='#advbuynow_prem']")
	private WebElement Btn_PremAdvanced;

	public WebElement getBtn_PremAdvanced() {
		return Btn_PremAdvanced;
	}

	/* Elite CTA's code */
	@FindBy(xpath = "//div[@data-product='QuickBooks Online Simple Start']//a[@data-di-id='#ssbuynow_elite']")
	private WebElement Btn_ElitesimpleStart;

	public WebElement getBtn_ElitesimpleStart() {
		return Btn_ElitesimpleStart;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Online Essentials']//a[@data-di-id='#esbuynow_elite']")
	private WebElement Btn_EliteEssentials;

	public WebElement getBtn_EliteEssentials() {
		return Btn_EliteEssentials;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Online Plus']//a[@data-di-id='#plbuynow_elite']")
	private WebElement Btn_ElitePlus;

	public WebElement getBtn_ElitePlus() {
		return Btn_ElitePlus;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Advanced']//a[@data-di-id='#advbuynow_elite']")
	private WebElement Btn_EliteAdvanced;

	public WebElement getBtn_EliteAdvanced() {
		return Btn_EliteAdvanced;
	}

	/* Compare page CTA's */
	@FindBy(xpath = "//div[@data-product='QuickBooks Online Simple Start']//a[contains(@id, 'buynow-url')]")
	private WebElement Btn_CompSimpleStart;

	public WebElement getBtn_CompSimpleStart() {
		return Btn_CompSimpleStart;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Online Essentials']//a[contains(@id, 'buynow-url')]")
	private WebElement Btn_CompEssential;

	public WebElement getBtn_CompEssential() {
		return Btn_CompEssential;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Online Plus']//a[contains(@id, 'buynow-url')]")
	private WebElement Btn_CompPlus;

	public WebElement getBtn_CompPlus() {
		return Btn_CompPlus;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Advanced']//a[contains(@id, 'buynow-url')]")
	private WebElement Btn_CompAdvanced;

	public WebElement getBtn_CompAdvanced() {
		return Btn_CompAdvanced;
	}

	/* Move Online Buy Now CTA */
	@FindBy(xpath = "//a[@data-di-id='#heroCTA_BuyNow']")
	private WebElement Btn_Buynow;

	public WebElement getBtn_Buynow() {
		return Btn_Buynow;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Online Essentials']//a[@data-di-id='#esbuynow']")
	private WebElement Btn_MacEssential;

	public WebElement getBtn_MacEssential() {
		return Btn_MacEssential;
	}

	/* Buynow CTA on Advanced */
	@FindBy(xpath = "//a[@data-di-id='#advbuynow_hero']")
	private WebElement Btn_BuynowAdv;

	public WebElement getBtn_BuynowAdv() {
		return Btn_BuynowAdv;
	}

	/* Buy now CTA on Simple start */
	@FindBy(xpath = "//a[@data-di-id='#ssbuynow-hero']")
	private WebElement Btn_BuynowSS;

	public WebElement getBtn_BuynowSS() {
		return Btn_BuynowSS;
	}

	// Buy Now Secondary Nav CTA on Simple Start
	@FindBy(xpath = "//div[@class='subnav-button-container']/a[@data-di-id='#SecondaryNav_BuynowCTA']")
	private WebElement SecNavBtn_BuynowSS;

	public WebElement getSecNavBtn_BuynowSS() {
		return SecNavBtn_BuynowSS;
	}

	// Tab for Essentials
	@FindBy(xpath = "//section[@class='sec-nav-desktop nav-container']//li[2]")
	private WebElement Essentials_Tab;

	public WebElement getEssentials_Tab() {
		return Essentials_Tab;
	}

	// Tab for Plus
	@FindBy(xpath = "//section[@class='sec-nav-desktop nav-container']//li[3]")
	private WebElement Plus_Tab;

	public WebElement getPlus_Tab() {
		return Plus_Tab;
	}

	/* Buy now CTA on Plus */
	@FindBy(xpath = "//a[@data-di-id='#plbuynow-hero']")
	private WebElement Btn_Buynowplus;

	public WebElement getBtn_Buynowplus() {
		return Btn_Buynowplus;
	}

	// Buy Now Secondary Nav CTA on Plus
	@FindBy(xpath = "//div[@class='subnav-button-container']/a[@data-di-id='#SecondaryNav_BuynowCTA']")
	private WebElement SecNavBtn_BuynowPlus;

	public WebElement getSecNavBtn_BuynowPlus() {
		return SecNavBtn_BuynowPlus;
	}

	/* Buy now CTA on Essentials */
	@FindBy(xpath = "//a[@data-di-id='#esbuynow-hero']")
	private WebElement Btn_BuynowEss;

	public WebElement getBtn_BuynowEss() {
		return Btn_BuynowEss;
	}

	// Buy Now Secondary Nav CTA on Essentials
	@FindBy(xpath = "//div[@class='subnav-button-container']/a[@data-di-id='#SecondaryNav_BuynowCTA']")
	private WebElement SecNavBtn_BuynowES;

	public WebElement getSecNavBtn_BuynowES() {
		return SecNavBtn_BuynowES;
	}

	@FindBy(xpath = "//div[@id='es-onofftoggle-5565']")
	private WebElement Toggle_Core;

	public WebElement Toggle_Core() {
		return Toggle_Core;
	}

	@FindBy(xpath = "//div[@id='fs-onofftoggle-5565']")
	private WebElement Toggle_Premium;

	public WebElement Toggle_Premium() {
		return Toggle_Premium;
	}

	@FindBy(xpath = "//div[@id='three-onofftoggle-5565']")
	private WebElement Toggle_Elite;

	public WebElement Toggle_Elite() {
		return Toggle_Elite;
	}

	/* CTA's for Plus after enabling of Toggle */
	@FindBy(xpath = "//div[@data-product='QuickBooks Online Plus']//a[contains(@id, 'buynow-addon1')]")
	private WebElement Btn_ToggleCore;

	public WebElement Btn_ToggleCore() {
		return Btn_ToggleCore;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Online Plus']//a[contains(@id, 'buynow-addon2')]")
	private WebElement Btn_TogglePremium;

	public WebElement Btn_TogglePremium() {
		return Btn_TogglePremium;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Online Plus']//a[contains(@id, 'buynow-addon2')]")
	private WebElement Btn_ToggleElite;

	public WebElement Btn_ToggleElite() {
		return Btn_ToggleElite;
	}

	/* CTA's for Advanced after enabling of Toggle */
	@FindBy(xpath = "//div[@data-product='QuickBooks Advanced']//a[contains(@id, 'buynow-addon1')]")
	private WebElement Btn_ToggleAdvCore;

	public WebElement Btn_ToggleAdvCore() {
		return Btn_ToggleAdvCore;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Advanced']//a[contains(@id, 'buynow-addon2')]")
	private WebElement Btn_ToggleAdvPremium;

	public WebElement Btn_ToggleAdvPremium() {
		return Btn_ToggleAdvPremium;
	}

	@FindBy(xpath = "//div[@data-product='QuickBooks Advanced']//a[contains(@id, 'buynow-addon3')]")
	private WebElement Btn_ToggleAdvElite;

	public WebElement Btn_ToggleAdvElite() {
		return Btn_ToggleAdvElite;
	}

	// Text to be verified on the plan cards for Payroll(Core,Premium,Elite)
	@FindBy(xpath = "//div[@class='payroll-txt payroll-show']")
	private List<WebElement> Text_cpayroll;

	public List<WebElement> getText_cpayroll() {
		return Text_cpayroll;
	}

}
