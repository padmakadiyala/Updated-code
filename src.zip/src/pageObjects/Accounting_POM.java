package pageObjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;

public class Accounting_POM extends Commons_POM {

	public Accounting_POM(){
		ElementLocatorFactory locatorWait = new AjaxElementLocatorFactory(driver, 30);
		PageFactory.initElements(locatorWait, this);
	}

	@FindBy(xpath="//div[contains(@class,'subnav-button-container')]//a[contains(@data-wa-link,'SecondaryNav_CTA')]")
	private WebElement BuyNow_Header;
	public WebElement getBuyNow_AHeader() {
		return BuyNow_Header;
	}

	@FindBy(xpath="//a[contains(@class,'base-button jumbo-button')]")
	private WebElement PlansandPricing_CTA;
	public WebElement getPlansandPricingCTA() {
		return PlansandPricing_CTA;
	}


	//Simple Start Container xpath for CTA, Text
	@FindBy(xpath="//div[@data-product='QuickBooks Online Simple Start']//a[contains(@id,'buynow-url')]")
	private WebElement BuyNow_AsimpleStart;
	public WebElement getBuyNow_AsimpleStart(){
		return BuyNow_AsimpleStart;
	}

	//MSRP price
	@FindBy(xpath="//div[contains(@id,'product-title')][@class='price-container-title']//following::div[@class='price']")
	private List<WebElement> Txt_strikePrice;
	public List<WebElement> getTxt_strikePrice(){
		return Txt_strikePrice;
	}

	//Discounted price
	@FindBy(xpath="//div[contains(@id,'product-title')][@class='price-container-title']//following::div[@class='red-price-text']")
	private List<WebElement> Discount_price;
	public List<WebElement> getDiscount_price(){
		return Discount_price;
	}

	//Text to be verified on the plan cards for % off
	@FindBy(xpath="//*[contains(@id,'offer-text')][@class='price-subhead-1']")
	private List<WebElement> Text_verification;
	public List<WebElement> getText_verification(){
		return Text_verification;
	}

	//Text to be verified on the plan cards for Core
	@FindBy(xpath="//*[contains(@id,'payroll-txt')][@class='price-subhead-2 addon1']")
	private List<WebElement> Text_cpayroll;
	public List<WebElement> getText_cpayroll(){
		return Text_cpayroll;
	}
	//Text to be verified on the plan cards for Premium
	@FindBy(xpath="//*[contains(@id,'payroll-txt')][@class='price-subhead-2 addon2']")
	private List<WebElement> Text_ppayroll;
	public List<WebElement> getText_ppayroll(){
		return Text_ppayroll;
	}
	//Text to be verified on the plan cards for Elite
	@FindBy(xpath="//*[contains(@id,'payroll-txt')][@class='price-subhead-2 addon3']")
	private List<WebElement> Text_epayroll;
	public List<WebElement> getText_epayroll(){
		return Text_epayroll;
	}


	@FindBy(xpath="//div[@data-product='QuickBooks Online Essentials']//a[contains(@id,'buynow-url')]")
	private WebElement BuyNow_Aessentials;
	public WebElement getBuyNow_Aessentials(){
		return BuyNow_Aessentials;
	}

	@FindBy(xpath="//div[@data-product='QuickBooks Online Plus']//a[contains(@id,'buynow-url')]")
	private WebElement BuyNow_Aplus;
	public WebElement getBuyNow_Aplus(){
		return BuyNow_Aplus;
	}

	@FindBy(xpath="//div[@data-product='QuickBooks Advanced']//a[contains(@id,'buynow-url')]")
	private WebElement BuyNow_Aadvanced;
	public WebElement getBuyNow_Aadvanced(){
		return BuyNow_Aadvanced;
	}

	/*  payroll with Core */

	@FindBy(xpath="//div[@data-product='QuickBooks Online Simple Start']//div[contains(@id,'es-onofftoggle')]")
	private WebElement SSToggle;
	public WebElement selectSS_Toggle(){
		return SSToggle;
	}

	@FindBy(xpath="//div[@data-product='QuickBooks Online Simple Start']//a[contains(@data-wa-link,'ssbuynow_core')]")
	private WebElement BuyNow_ASsimpleStart;
	public WebElement getBuyNow_ASsimpleStart(){
		return BuyNow_ASsimpleStart;
	}

	@FindBy(xpath="//div[@data-product='QuickBooks Online Essentials']//a[contains(@data-wa-link,'esbuynow_core')]")
	private WebElement BuyNow_ASessentials;
	public WebElement getBuyNow_ASessentials(){
		return BuyNow_ASessentials;
	}

	@FindBy(xpath="//div[@data-product='QuickBooks Online Plus']//a[contains(@data-wa-link,'plbuynow_core')]")
	private WebElement BuyNow_ASplus;
	public WebElement getBuyNow_ASplus(){
		return BuyNow_ASplus;
	}

	@FindBy(xpath="//div[@data-product='QuickBooks Advanced']//a[contains(@data-wa-link,'advbuynow_core')]")
	private WebElement BuyNow_ASadvanced;
	public WebElement getBuyNow_ASadvanced(){
		return BuyNow_ASadvanced;
	}

	/*  payroll with Premium */

	@FindBy(xpath="//div[@data-product='QuickBooks Online Simple Start']//div[contains(@id,'fs-onofftoggle')]")
	private WebElement FSToggle;
	public WebElement selectFS_Toggle(){
		return FSToggle;
	}

	@FindBy(xpath="//div[@data-product='QuickBooks Online Simple Start']//a[contains(@data-wa-link,'ssbuynow_prem')]")
	private WebElement BuyNow_AFsimpleStart;
	public WebElement getBuyNow_AFsimpleStart(){
		return BuyNow_AFsimpleStart;
	}

	@FindBy(xpath="//div[@data-product='QuickBooks Online Essentials']//a[contains(@data-wa-link,'esbuynow_prem')]")
	private WebElement BuyNow_AFessentials;
	public WebElement getBuyNow_AFessentials(){
		return BuyNow_AFessentials;
	}

	@FindBy(xpath="//div[@data-product='QuickBooks Online Plus']//a[contains(@data-wa-link,'plbuynow_prem')]")
	private WebElement BuyNow_AFplus;
	public WebElement getBuyNow_AFplus(){
		return BuyNow_AFplus;
	}

	@FindBy(xpath="//div[@data-product='QuickBooks Advanced']//a[contains(@data-wa-link,'advbuynow_prem')]")
	private WebElement BuyNow_AFadvanced;
	public WebElement getBuyNow_AFadvanced(){
		return BuyNow_AFadvanced;
	}

	/*  payroll with Elite */

	@FindBy(xpath="//div[@data-product='QuickBooks Online Simple Start']//div[contains(@id,'three-onofftoggle')]")
	private WebElement PremiumToggle;
	public WebElement selectPremium_Toggle(){
		return PremiumToggle;
	} 

	@FindBy(xpath="//div[@data-product='QuickBooks Online Simple Start']//a[contains(@id,'buynow-addon3-url')]")
	private WebElement BuyNow_APsimpleStart;
	public WebElement getBuyNow_APsimpleStart(){
		return BuyNow_APsimpleStart;
	}

	@FindBy(xpath="//div[@data-product='QuickBooks Online Essentials']//a[contains(@id,'buynow-addon3-url')]")
	private WebElement BuyNow_APessentials;
	public WebElement getBuyNow_APessentials(){
		return BuyNow_APessentials;
	}

	@FindBy(xpath="//div[@data-product='QuickBooks Online Plus']//a[contains(@id,'buynow-addon3-url')]")
	private WebElement BuyNow_APplus;
	public WebElement getBuyNow_APplus(){
		return BuyNow_APplus;
	}

	@FindBy(xpath="//div[@data-product='QuickBooks Advanced']//a[contains(@id,'buynow-addon3-url')]")
	private WebElement BuyNow_APadvanced;
	public WebElement getBuyNow_APadvanced(){
		return BuyNow_APadvanced;
	}

	// --- Core Payroll --
	@FindBy(xpath="//div[@data-product='QuickBooks Advanced']//div[contains(@id,'es-onofftoggle')]")  
	private WebElement JCoreToggle;
	public WebElement selectJCoreToggle() {
		return JCoreToggle;
	}
	@FindBy(xpath="//div[@data-product='QuickBooks Online Plus']//span[contains(@id,'buynow-addon1-cta')]")
	private WebElement Buynow_JCorePlus;
	public WebElement getBuynow_JCorePlus(){
		return Buynow_JCorePlus;
	}
	@FindBy(xpath="//div[@data-product='QuickBooks Advanced']//a[contains(@id,'buynow-addon1-url')]")
	private WebElement Buynow_JCoreAdvanced;
	public WebElement getBuynow_JCoreAdvanced(){
		return Buynow_JCoreAdvanced;
	}

	//--- Premium Payroll ---

	@FindBy(xpath="//div[@data-product='QuickBooks Advanced']//div[contains(@id,'fs-onofftoggle')]")  
	private WebElement JPremiumToggle;
	public WebElement selectJPremiumToggle() {
		return JPremiumToggle;
	}
	@FindBy(xpath="//div[@data-product='QuickBooks Online Plus']//span[contains(@id,'buynow-addon2-cta')]")
	private WebElement Buynow_JobPremiumPlus;
	public WebElement getBuynow_JPremiumPlus(){
		return Buynow_JobPremiumPlus;
	}
	@FindBy(xpath="//div[@data-product='QuickBooks Advanced']//a[contains(@id,'buynow-addon2-url')]")
	private WebElement Buynow_JobPremiumAdvanced;
	public WebElement getBuynow_JPremiumAdvanced(){
		return Buynow_JobPremiumAdvanced;
	}
	//--- Elite Payroll ---

	@FindBy(xpath="//div[@data-product='QuickBooks Advanced']//div[contains(@id,'three-onofftoggle')]")  
	private WebElement JEliteToggle;
	public WebElement selectJEliteToggle() {
		return JEliteToggle;
	}
	@FindBy(xpath="//div[@data-product='QuickBooks Online Plus']//span[contains(@id,'buynow-addon3-cta')]")
	private WebElement Buynow_JobElitePlus;
	public WebElement getBuynow_JElitePlus(){
		return Buynow_JobElitePlus;
	}
	@FindBy(xpath="//div[@data-product='QuickBooks Advanced']//a[contains(@id,'buynow-addon3-url')]")
	private WebElement Buynow_JobEliteAdvanced;
	public WebElement getBuynow_JEliteAdvanced(){
		return Buynow_JobEliteAdvanced;
	}
	
}
