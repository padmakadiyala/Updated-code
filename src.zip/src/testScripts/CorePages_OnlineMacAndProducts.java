package testScripts;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.qb.constants.UtilConstants;
import com.qb.initializer.InitialiserClass;

import functionLibrary.ErrorHandling;
import functionLibrary.Utilities;
import functionLibrary.actions;
import pageObjects.Accounting_POM;
import pageObjects.Home_POM;
import pageObjects.Online_POM;

public class CorePages_OnlineMacAndProducts extends InitialiserClass {

	public CorePages_OnlineMacAndProducts(WebDriver driver) {
		Logger.getLogger(CorePages_OnlineMacAndProducts.class.getName());
		home = new Home_POM();
		online = new Online_POM();
		util = new Utilities();
		acctPricing = new Accounting_POM();

	}

	public String VerifyOnlineMacandProducts() {
		String link[] = { "online/mac", "industry/retail" };
		int linkLength = link.length - 1;

		try {

			for (int i = 0; i <= linkLength; i++) {

				System.out.println(link[i]);
				Log.info("         ");
				Log.info("----Executing Test Case:   //quickbooks.intuit.com/" + link[i] + "------");
				Log.info("         ");

				driver.navigate().to(UtilConstants.siteURI + link[i]);

				Utilities.setExcelFile(UtilConstants.pathDataSheet, 1);

				actions.waitAndClick(online.getBtn_CompSimpleStart());
				actions.verificationPoint(Utilities.getCellData(1, 1), util.getURL());
				actions.navigateBack();

				actions.waitAndClick(online.getBtn_MacEssential());
				actions.verificationPoint(Utilities.getCellData(2, 1), util.getURL());
				actions.navigateBack();

				actions.waitAndClick(online.getBtn_CompPlus());
				actions.verificationPoint(Utilities.getCellData(3, 1), util.getURL());
				actions.navigateBack();

				Log.info("----------------Verification and comparison of MSRP price for Standalone----------------");
				Utilities.setExcelFile(UtilConstants.pathOfferIdsSheet, 1);
				actions.verificationPoint(Utilities.getCellData(1, 2),
						acctPricing.getTxt_strikePrice().get(0).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(2, 2),
						acctPricing.getTxt_strikePrice().get(1).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(3, 2),
						acctPricing.getTxt_strikePrice().get(2).getText().replaceAll("\\s", ""));
				Log.info("----------------Verification and comparison of Discounted Price Standalone----------------");
				actions.verificationPoint(Utilities.getCellData(1, 4),
						acctPricing.getDiscount_price().get(0).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(2, 4),
						acctPricing.getDiscount_price().get(1).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(3, 4),
						acctPricing.getDiscount_price().get(2).getText().replaceAll("\\s", ""));
				/*
				 * Log.
				 * info("----------------Verification of Text 70%off on the price cards for the  Standalone----------------"
				 * ); actions.verificationPoint(Utilities.getCellData(1,
				 * 3),acctPricing.getText_verification().get(0).getText());
				 * actions.verificationPoint(Utilities.getCellData(2,
				 * 3),acctPricing.getText_verification().get(1).getText());
				 * actions.verificationPoint(Utilities.getCellData(3,
				 * 3),acctPricing.getText_verification().get(2).getText());
				 * actions.verificationPoint(Utilities.getCellData(4,
				 * 3),acctPricing.getText_verification().get(3).getText()); waits.hardWait(3);
				 */

			}

			Log.info("----------------The Test Case Passed----------------");

			return "Pass";

		} catch (Exception e) {
			Log.error("************Test case Failed**********");
			ErrorHandling.handleExceptions(e);
			return "Fail";
		} catch (AssertionError e) {
			Log.error("************Test case Failed**********");
			ErrorHandling.handleAssertionError(e);
			return "Fail";

		}
	}
}
