package testScripts;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.qb.constants.UtilConstants;
import com.qb.initializer.InitialiserClass;

import functionLibrary.ErrorHandling;
import functionLibrary.Utilities;
import functionLibrary.actions;
import pageObjects.Home_POM;
import pageObjects.Online_POM;

public class CorePages_OnlineAdvanced extends InitialiserClass {
	
	public CorePages_OnlineAdvanced(WebDriver driver) {
		Logger.getLogger(CorePages_OnlineAdvanced.class.getName());
		home = new Home_POM();
		online = new Online_POM();
		util = new Utilities();

	}

	public String VerifyOnlineAdvanced(){
		String link[] = {"online/advanced"};
		int linkLength = link.length-1;

		try{
			Log.info("----------------Executing Test Case: Online Advanced ----------------");

			for(int i=0;i<=linkLength;i++){

				Log.info("link[i]");

				driver.navigate().to(UtilConstants.siteURI+ link[i]);


				Utilities.setExcelFile(UtilConstants.pathDataSheet, 0);
				actions.waitAndClick(online.getBtn_BuynowAdv());
				actions.windowTab(1);
				actions.verificationPoint(Utilities.getCellData(4, 1), util.getURL());
				driver.close();
				actions.windowTab(0);


			}

			Log.info("----------------The Test Case Passed----------------");

			return "Pass";

		}catch(Exception e){
			Log.error("************Test case Failed**********");
			ErrorHandling.handleExceptions(e);
			return "Fail";
		}catch(AssertionError e){
			Log.error("************Test case Failed**********");
			ErrorHandling.handleAssertionError(e);
			return "Fail";

		}
	}

}
