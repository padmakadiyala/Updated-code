package testScripts;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.qb.constants.UtilConstants;
import com.qb.initializer.InitialiserClass;

import functionLibrary.ErrorHandling;
import functionLibrary.Utilities;
import functionLibrary.actions;
import pageObjects.Home_POM;
import pageObjects.Online_POM;

public class CorePages_OnlineCompareValidation extends InitialiserClass {
	public CorePages_OnlineCompareValidation(WebDriver driver) {
		Logger.getLogger(CorePages_OnlineCompareValidation.class.getName());
		home = new Home_POM();
		online = new Online_POM();
		util = new Utilities();
	}

	public String VerifyOnlineCompare() {
		String link[] = { "online/compare" };
		int linkLength = link.length - 1;

		try {
			Log.info("----------------Executing Test Case: Payroll Online Compare----------------");

			for (int i = 0; i <= linkLength; i++) {

				Log.info("link[i]");
				// System.out.println(link[i]);

				driver.navigate().to(UtilConstants.siteURI + link[i]);

				Utilities.setExcelFile(UtilConstants.pathDataSheet, 1);

				actions.waitAndClick(online.getBtn_CompSimpleStart());
				actions.verificationPoint(Utilities.getCellData(1, 1), util.getURL());
				actions.navigateBack();

				actions.waitAndClick(online.getBtn_CompEssential());
				actions.verificationPoint(Utilities.getCellData(2, 1), util.getURL());
				actions.navigateBack();

				actions.waitAndClick(online.getBtn_CompPlus());
				actions.verificationPoint(Utilities.getCellData(3, 1), util.getURL());
				actions.navigateBack();

				actions.waitAndClick(online.getBtn_CompAdvanced());
				actions.verificationPoint(Utilities.getCellData(4, 1), util.getURL());
				actions.navigateBack();
			}

			Log.info("----------------The Test Case Passed----------------");

			return "Pass";

		} catch (Exception e) {
			Log.error("************Test case Failed**********");
			ErrorHandling.handleExceptions(e);
			return "Fail";
		} catch (AssertionError e) {
			Log.error("************Test case Failed**********");
			ErrorHandling.handleAssertionError(e);
			return "Fail";

		}
	}

}