package testScripts;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import com.qb.constants.UtilConstants;
import com.qb.initializer.InitialiserClass;
import functionLibrary.ErrorHandling;
import functionLibrary.Utilities;
import functionLibrary.actions;
import pageObjects.Accounting_POM;
import pageObjects.Home_POM;

public class Accounting_4PriceCardsReportingSites extends InitialiserClass {

	public Accounting_4PriceCardsReportingSites(WebDriver driver) {
		Logger.getLogger(Accounting_4PriceCardsReportingSites.class.getName());
		home = new Home_POM();
		acctPricing = new Accounting_POM();
		util = new Utilities();
	}

	public String AcctVerifyOfferIds() {

		String link[] = {  "", "balance-sheet", "cash-flow", "income-statement" };
		int linkLength = link.length - 1;

		try {

			for (int i = 0; i <= linkLength; i++) {

				System.out.println(link[i]);
				Log.info("         ");
				Log.info("----Executing Test Case:   //quickbooks.intuit.com/accounting/reporting/"+link[i]+"------");
				Log.info("         ");
				driver.navigate().to("https://quickbooks.intuit.com/accounting/reporting/" + link[i]);

			
				Log.info("----------------Verification of Buy Nows for Standalone products----------------");
				actions.scrollAndClick(acctPricing.getBuyNow_AsimpleStart());
				Utilities.setExcelFile(UtilConstants.pathDataSheet, 1);
				actions.verificationPoint(Utilities.getCellData(1, 1), util.getURL());
				actions.navigateBack();
				//waits.hardWait(3);

				actions.scrollAndClick(acctPricing.getBuyNow_Aessentials());
				actions.verificationPoint(Utilities.getCellData(2, 1), util.getURL());
				actions.navigateBack();

				actions.scrollAndClick(acctPricing.getBuyNow_Aplus());
				actions.verificationPoint(Utilities.getCellData(3, 1), util.getURL());
				actions.navigateBack();

				actions.scrollAndClick(acctPricing.getBuyNow_Aadvanced());
				actions.verificationPoint(Utilities.getCellData(4, 1), util.getURL());
				actions.navigateBack();

				Log.info("-------Verification of Buy Nows for Core Payroll Test------------");

				actions.waitAndClick(acctPricing.selectSS_Toggle());
				waits.hardWait(2);
				actions.scrollAndClick(acctPricing.getBuyNow_ASsimpleStart());
				actions.verificationPoint(Utilities.getCellData(5, 1), util.getURL());
				actions.navigateBack();

				actions.waitAndClick(acctPricing.selectSS_Toggle());
				actions.scrollAndClick(acctPricing.getBuyNow_ASessentials());
				actions.verificationPoint(Utilities.getCellData(6, 1), util.getURL());
				actions.navigateBack();

				actions.waitAndClick(acctPricing.selectSS_Toggle());
				actions.scrollAndClick(acctPricing.getBuyNow_ASplus());
				actions.verificationPoint(Utilities.getCellData(7, 1), util.getURL());
				util.getScreenShot("BuyNow_Plus");
				actions.navigateBack();

				actions.waitAndClick(acctPricing.selectSS_Toggle());
				actions.scrollAndClick(acctPricing.getBuyNow_ASadvanced());
				actions.verificationPoint(Utilities.getCellData(8, 1), util.getURL());
				actions.navigateBack();

				Log.info("-------Verification of Buy Nows for Premium Payroll Test------------");

				actions.waitAndClick(acctPricing.selectFS_Toggle());
				waits.hardWait(2);
				actions.scrollAndClick(acctPricing.getBuyNow_AFsimpleStart());
				actions.verificationPoint(Utilities.getCellData(9, 1), util.getURL());
				actions.navigateBack();

				actions.waitAndClick(acctPricing.selectFS_Toggle());
				actions.scrollAndClick(acctPricing.getBuyNow_AFessentials());
				actions.verificationPoint(Utilities.getCellData(10, 1), util.getURL());
				actions.navigateBack();

				actions.waitAndClick(acctPricing.selectFS_Toggle());
				actions.scrollAndClick(acctPricing.getBuyNow_AFplus());
				actions.verificationPoint(Utilities.getCellData(11, 1), util.getURL());
				actions.navigateBack();

				actions.waitAndClick(acctPricing.selectFS_Toggle());
				actions.scrollAndClick(acctPricing.getBuyNow_AFadvanced());
				actions.verificationPoint(Utilities.getCellData(12, 1), util.getURL());
				actions.navigateBack();

				Log.info("-------Verification of Buy Nows for Elite Payroll Test------------");

				actions.waitAndClick(acctPricing.selectPremium_Toggle());
				waits.hardWait(2);
				actions.scrollAndClick(acctPricing.getBuyNow_APsimpleStart());
				actions.verificationPoint(Utilities.getCellData(13, 1), util.getURL());
				actions.navigateBack();

				actions.waitAndClick(acctPricing.selectPremium_Toggle());
				actions.scrollAndClick(acctPricing.getBuyNow_APessentials());
				actions.verificationPoint(Utilities.getCellData(14, 1), util.getURL());
				actions.navigateBack();

				actions.waitAndClick(acctPricing.selectPremium_Toggle());
				actions.scrollAndClick(acctPricing.getBuyNow_APplus());
				actions.verificationPoint(Utilities.getCellData(15, 1), util.getURL());
				actions.navigateBack();

				actions.waitAndClick(acctPricing.selectPremium_Toggle());
				actions.scrollAndClick(acctPricing.getBuyNow_APadvanced());
				actions.verificationPoint(Utilities.getCellData(16, 1), util.getURL());
				actions.navigateBack();
				
				Log.info("----------------Verification and comparison of MSRP price for Standalone----------------");
				Utilities.setExcelFile(UtilConstants.pathOfferIdsSheet, 1);
				actions.verificationPoint(Utilities.getCellData(1, 2),acctPricing.getTxt_strikePrice().get(0).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(2, 2),acctPricing.getTxt_strikePrice().get(1).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(3, 2),acctPricing.getTxt_strikePrice().get(2).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(4, 2),acctPricing.getTxt_strikePrice().get(3).getText().replaceAll("\\s", ""));
				Log.info("----------------Verification and comparison of Discounted Price Standalone----------------");
				actions.verificationPoint(Utilities.getCellData(1, 4),acctPricing.getDiscount_price().get(0).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(2, 4),acctPricing.getDiscount_price().get(1).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(3, 4),acctPricing.getDiscount_price().get(2).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(4, 4),acctPricing.getDiscount_price().get(3).getText().replaceAll("\\s", ""));
				/*Log.info("----------------Verification of Text 70%off on the price cards for the  Standalone----------------");
				actions.verificationPoint(Utilities.getCellData(1, 3),acctPricing.getText_verification().get(0).getText());
				actions.verificationPoint(Utilities.getCellData(2, 3),acctPricing.getText_verification().get(1).getText());
				actions.verificationPoint(Utilities.getCellData(3, 3),acctPricing.getText_verification().get(2).getText());
				actions.verificationPoint(Utilities.getCellData(4, 3),acctPricing.getText_verification().get(3).getText());
				waits.hardWait(3);*/

				Log.info("----------------Verification and comparison of MSRP price for Core Payroll----------------");
				actions.waitAndClick(acctPricing.selectSS_Toggle());
				actions.verificationPoint(Utilities.getCellData(7, 2),acctPricing.getTxt_strikePrice().get(0).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(12, 2),acctPricing.getTxt_strikePrice().get(1).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(17, 2),acctPricing.getTxt_strikePrice().get(2).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(22, 2),acctPricing.getTxt_strikePrice().get(3).getText().replaceAll("\\s", ""));
				Log.info("----------------Verification and comparison of Discounted price for Core Payroll----------------");
				actions.verificationPoint(Utilities.getCellData(7, 4),acctPricing.getDiscount_price().get(0).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(12, 4),acctPricing.getDiscount_price().get(1).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(17, 4),acctPricing.getDiscount_price().get(2).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(22, 4),acctPricing.getDiscount_price().get(3).getText().replaceAll("\\s", ""));
				/*Log.info("----------------Verification of Text 70%off on the price cards for the Core Payroll----------------");
				actions.verificationPoint(Utilities.getCellData(7, 3),acctPricing.getText_verification().get(0).getText());
				actions.verificationPoint(Utilities.getCellData(12, 3),acctPricing.getText_verification().get(1).getText());
				actions.verificationPoint(Utilities.getCellData(17, 3),acctPricing.getText_verification().get(2).getText());
				actions.verificationPoint(Utilities.getCellData(22, 3),acctPricing.getText_verification().get(3).getText());*/
				Log.info("----------------Verification of Text on the price cards for the Core Payroll----------------");
				actions.verificationPoint(Utilities.getCellData(7, 5),acctPricing.getText_cpayroll().get(0).getText());
				actions.verificationPoint(Utilities.getCellData(12, 5),acctPricing.getText_cpayroll().get(1).getText());
				actions.verificationPoint(Utilities.getCellData(17, 5),acctPricing.getText_cpayroll().get(2).getText());
				actions.verificationPoint(Utilities.getCellData(22, 5),acctPricing.getText_cpayroll().get(3).getText());
				waits.hardWait(3);
				
				Log.info("----------------Verification and comparison of MSRP price for Premium Payroll----------------");
				actions.waitAndClick(acctPricing.selectFS_Toggle());
				actions.verificationPoint(Utilities.getCellData(8, 2),acctPricing.getTxt_strikePrice().get(0).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(13, 2),acctPricing.getTxt_strikePrice().get(1).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(18, 2),acctPricing.getTxt_strikePrice().get(2).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(23, 2),acctPricing.getTxt_strikePrice().get(3).getText().replaceAll("\\s", ""));
				Log.info("----------------Verification and comparison of Discounted price for Premium Payroll----------------");
				actions.verificationPoint(Utilities.getCellData(8, 4),acctPricing.getDiscount_price().get(0).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(13, 4),acctPricing.getDiscount_price().get(1).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(18, 4),acctPricing.getDiscount_price().get(2).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(23, 4),acctPricing.getDiscount_price().get(3).getText().replaceAll("\\s", ""));
				/*Log.info("----------------Verification of Text 70%off on the price cards for the Premium Payroll----------------");
				actions.verificationPoint(Utilities.getCellData(8, 3),acctPricing.getText_verification().get(0).getText());
				actions.verificationPoint(Utilities.getCellData(13, 3),acctPricing.getText_verification().get(1).getText());
				actions.verificationPoint(Utilities.getCellData(18, 3),acctPricing.getText_verification().get(2).getText());
				actions.verificationPoint(Utilities.getCellData(23, 3),acctPricing.getText_verification().get(3).getText());*/
				Log.info("----------------Verification of Text on the price cards for the Core Payroll----------------");
				actions.verificationPoint(Utilities.getCellData(8, 5),acctPricing.getText_ppayroll().get(0).getText());
				actions.verificationPoint(Utilities.getCellData(13, 5),acctPricing.getText_ppayroll().get(1).getText());
				actions.verificationPoint(Utilities.getCellData(18, 5),acctPricing.getText_ppayroll().get(2).getText());
				actions.verificationPoint(Utilities.getCellData(23, 5),acctPricing.getText_ppayroll().get(3).getText());
				waits.hardWait(3);
				
				Log.info("----------------Verification and comparison of MSRP price for Elite Payroll----------------");
				actions.waitAndClick(acctPricing.selectPremium_Toggle());
				actions.verificationPoint(Utilities.getCellData(9, 2),acctPricing.getTxt_strikePrice().get(0).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(14, 2),acctPricing.getTxt_strikePrice().get(1).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(19, 2),acctPricing.getTxt_strikePrice().get(2).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(24, 2),acctPricing.getTxt_strikePrice().get(3).getText().replaceAll("\\s", ""));
				Log.info("----------------Verification and comparison of Discounted price for Elite Payroll----------------");
				actions.verificationPoint(Utilities.getCellData(9, 4),acctPricing.getDiscount_price().get(0).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(14, 4),acctPricing.getDiscount_price().get(1).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(19, 4),acctPricing.getDiscount_price().get(2).getText().replaceAll("\\s", ""));
				actions.verificationPoint(Utilities.getCellData(24, 4),acctPricing.getDiscount_price().get(3).getText().replaceAll("\\s", ""));
				/*Log.info("----------------Verification of Text 70% off on the price cards for the Elite Payroll----------------");
				actions.verificationPoint(Utilities.getCellData(9, 3),acctPricing.getText_verification().get(0).getText());
				actions.verificationPoint(Utilities.getCellData(14, 3),acctPricing.getText_verification().get(1).getText());
				actions.verificationPoint(Utilities.getCellData(19, 3),acctPricing.getText_verification().get(2).getText());
				actions.verificationPoint(Utilities.getCellData(24, 3),acctPricing.getText_verification().get(3).getText());*/
				Log.info("----------------Verification of Text on the price cards for the Elite Payroll----------------");
				actions.verificationPoint(Utilities.getCellData(9, 5),acctPricing.getText_epayroll().get(0).getText());
				actions.verificationPoint(Utilities.getCellData(14, 5),acctPricing.getText_epayroll().get(1).getText());
				actions.verificationPoint(Utilities.getCellData(19, 5),acctPricing.getText_epayroll().get(2).getText());
				actions.verificationPoint(Utilities.getCellData(24, 5),acctPricing.getText_epayroll().get(3).getText());
				waits.hardWait(3);
			}

			Log.info("----------------The Test Case Passed----------------");
			Log.info("         ");

			return "Pass";

		} catch (Exception e) {
			Log.error("************Test case Failed**********");
			ErrorHandling.handleExceptions(e);
			return "Fail";
		} catch (AssertionError e) {
			Log.error("************Test case Failed**********");
			ErrorHandling.handleAssertionError(e);
			return "Fail";

		}

	}
}
