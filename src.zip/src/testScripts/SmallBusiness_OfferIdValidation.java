package testScripts;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.qb.constants.UtilConstants;
import com.qb.initializer.InitialiserClass;
import pageObjects.Home_POM;
import pageObjects.PlansAndPricing_POM;
import functionLibrary.ErrorHandling;
import functionLibrary.Utilities;
import functionLibrary.actions;

public class SmallBusiness_OfferIdValidation extends InitialiserClass {
	
	public SmallBusiness_OfferIdValidation(WebDriver driver) {
		 Logger.getLogger(SmallBusiness_OfferIdValidation.class.getName());
		 home = new Home_POM();
		 plansPricing = new PlansAndPricing_POM();
		 util = new Utilities();
	}
	public String VerifyOfferIds(){

		try{
			Log.info("----------------Executing Test Case: UpdateMyAccountMyInformation----------------");
			
			
			actions.waitAndClick(home.getplansAndPricing());
			actions.waitAndClick(plansPricing.getBuyNow_simpleStart());
			
			Utilities.setExcelFile(UtilConstants.pathDataSheet, 0);
			
			actions.verificationPoint(Utilities.getCellData(1, 1), util.getURL());
			
			actions.navigateBack();
			//actions.waitAndClick(home.getLnkVisitUSSite());
			actions.waitAndClick(plansPricing.getBuyNow_Essentials());
			actions.verificationPoint(Utilities.getCellData(2, 1), util.getURL());
			
			actions.navigateBack();
			//actions.waitAndClick(home.getLnkVisitUSSite());
			actions.waitAndClick(plansPricing.getBuyNow_Plus());
			actions.verificationPoint(Utilities.getCellData(3, 1), util.getURL());
			util.getScreenShot("BuyNow_Plus");
			
			actions.navigateBack();
			//actions.waitAndClick(home.getLnkVisitUSSite());
			actions.waitAndClick(plansPricing.getBuyNow_Advanced());
			actions.verificationPoint(Utilities.getCellData(4, 1), util.getURL());
			
			
			Log.info("----------------The Test Case Passed----------------");
			
			return "Pass";
			
		}catch(Exception e){
			Log.error("************Test case Failed**********");
			ErrorHandling.handleExceptions(e);
		return "Fail";
		}catch(AssertionError e){
			Log.error("************Test case Failed**********");
			ErrorHandling.handleAssertionError(e);
		return "Fail";
	
	}
	}		
}