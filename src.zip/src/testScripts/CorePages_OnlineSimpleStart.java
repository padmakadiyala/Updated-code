package testScripts;

import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.qb.constants.UtilConstants;
import com.qb.initializer.InitialiserClass;

import functionLibrary.ErrorHandling;
import functionLibrary.Utilities;
import functionLibrary.actions;
import pageObjects.Home_POM;
import pageObjects.Online_POM;

public class CorePages_OnlineSimpleStart extends InitialiserClass {

	public CorePages_OnlineSimpleStart(WebDriver driver) {
		Logger.getLogger(CorePages_OnlineSimpleStart.class.getName());
		home = new Home_POM();
		online = new Online_POM();
		util = new Utilities();

	}

	public String VerifyOnlineSimpleStart() {
		String link[] = { "online/simple-start" };
		int linkLength = link.length - 1;

		try {
			Log.info("----------------Executing Test Case: Online SimpleStart Page ----------------");

			for (int i = 0; i <= linkLength; i++) {

				Log.info("link[i]");

				driver.navigate().to("https://quickbooks.intuit.com/" + link[i]);

				Log.info("----------------Verification of Buy Nows fon Simple Start Page----------------");
				Utilities.setExcelFile(UtilConstants.pathDataSheet, 1);
				actions.waitAndClick(online.getSecNavBtn_BuynowSS());
				actions.verificationPoint(Utilities.getCellData(1, 1), util.getURL());
				actions.navigateBack();
				actions.waitAndClick(online.getBtn_BuynowSS());
				actions.windowTab(1);
				actions.verificationPoint(Utilities.getCellData(1, 1), util.getURL());
				driver.close();
				actions.windowTab(0);
				waits.hardWait(3);

				Log.info("----------------Verification of Buy Nows fon Essentials Page----------------");
				actions.waitAndClick(online.getEssentials_Tab());
				actions.waitAndClick(online.getSecNavBtn_BuynowES());
				actions.verificationPoint(Utilities.getCellData(2, 1), util.getURL());
				actions.navigateBack();
				actions.waitAndClick(online.getBtn_BuynowEss());
				actions.windowTab(1);
				actions.verificationPoint(Utilities.getCellData(2, 1), util.getURL());
				driver.close();
				actions.windowTab(0);
				waits.hardWait(3);

				Log.info("----------------Verification of Buy Nows fon Plus Page----------------");
				actions.waitAndClick(online.getPlus_Tab());
				actions.waitAndClick(online.getSecNavBtn_BuynowPlus());
				actions.verificationPoint(Utilities.getCellData(3, 1), util.getURL());
				actions.navigateBack();
				actions.waitAndClick(online.getBtn_Buynowplus());
				actions.windowTab(1);
				actions.verificationPoint(Utilities.getCellData(3, 1), util.getURL());
				driver.close();
				actions.windowTab(0);
				waits.hardWait(3);
			}

			Log.info("----------------The Test Case Passed----------------");

			return "Pass";

		} catch (Exception e) {
			Log.error("************Test case Failed**********");
			ErrorHandling.handleExceptions(e);
			return "Fail";
		} catch (AssertionError e) {
			Log.error("************Test case Failed**********");
			ErrorHandling.handleAssertionError(e);
			return "Fail";

		}
	}

}
