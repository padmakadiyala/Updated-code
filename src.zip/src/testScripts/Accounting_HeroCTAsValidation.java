package testScripts;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.qb.constants.UtilConstants;
import com.qb.initializer.InitialiserClass;

import functionLibrary.ErrorHandling;
import functionLibrary.Utilities;
import functionLibrary.actions;
import pageObjects.Accounting_POM;
import pageObjects.Home_POM;

public class Accounting_HeroCTAsValidation extends InitialiserClass {

	public Accounting_HeroCTAsValidation(WebDriver driver) {
		Logger.getLogger(Accounting_HeroCTAsValidation.class.getName());
		home = new Home_POM();
		acctPricing = new Accounting_POM();
		util = new Utilities();
	}

	public String AcctVerifyHeroCTAs() {

		String link[] = { "", "sales-tax", "invoicing", "track-expenses", "estimates-proposals", "tax-deductions", "contractors", "mileage", "reporting/income-statement", "reporting", "reporting/balance-sheet", "reporting/cash-flow", "reporting/income-statement" };
		int linkLength = link.length - 1;

		try {

			for (int i = 0; i <= linkLength; i++) {

				System.out.println(link[i]);
				Log.info("         ");
				Log.info("----Executing Header CTAs Test Case:   //quickbooks.intuit.com/accounting/" + link[i] + "------");
				Log.info("         ");
				driver.navigate().to("https://quickbooks.intuit.com/accounting/" + link[i]);

				// Header section CTAs verification
				actions.waitAndClick(acctPricing.getBuyNow_AHeader());
				waits.hardWait(3);
				actions.navigateBack();
				actions.waitAndClick(acctPricing.getPlansandPricingCTA());

			}
			Log.info("----------------The Test Case Passed----------------");
			Log.info("         ");

			return "Pass";

		} catch (Exception e) {
			Log.error("************Test case Failed**********");
			ErrorHandling.handleExceptions(e);
			return "Fail";
		} catch (AssertionError e) {
			Log.error("************Test case Failed**********");
			ErrorHandling.handleAssertionError(e);
			return "Fail";

		}

	}

}
