package testScripts;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.qb.constants.UtilConstants;
import com.qb.initializer.InitialiserClass;

import functionLibrary.ErrorHandling;
import functionLibrary.Utilities;
import functionLibrary.actions;
import pageObjects.Home_POM;
import pageObjects.PlansAndPricing_POM;

public class Freetrial_PlansandPricing extends InitialiserClass{
	
	
	public Freetrial_PlansandPricing(WebDriver driver) {
		 Logger.getLogger(Freetrial_PlansandPricing.class.getName());
		 home = new Home_POM();
		 util = new Utilities();
		 plansPricing = new PlansAndPricing_POM();
		 
		 
	}
	
	public String VerifyFreetrial(){
		
		String link[] = {"pricing"};
		int linkLength = link.length-1;		

		try{
			Log.info("----------------Executing Test Case: Organizebooks_FT_PlansNPricing----------------");
			
			for(int i=0;i<=linkLength;i++){
			Log.info("link[i]");
			driver.navigate().to("https://quickbooks.intuit.com/"+ link[i]);
			
			//driver.get("https://quickbooks.intuit.com/pricing/");
			//actions.waitAndClick(plansPricing.getPlansnpricing_Link());
			actions.waitAndClick(plansPricing.FreeTrial_toggle());
			
			Utilities.setExcelFile(UtilConstants.pathDataSheet, 1);
			
			actions.waitAndClick(plansPricing.getFreeTrial_SimpleStart());
			actions.verificationPoint(Utilities.getCellData(1, 1), util.getURL());
						
			actions.navigateBack();
			actions.waitAndClick(plansPricing.FreeTrial_toggle());
			actions.waitAndClick(plansPricing.getFreeTrial_Essentials());
			actions.verificationPoint(Utilities.getCellData(2, 1), util.getURL());
						
			actions.navigateBack();
			actions.waitAndClick(plansPricing.FreeTrial_toggle());
			actions.waitAndClick(plansPricing.getFreeTrial_Plus());
			actions.verificationPoint(Utilities.getCellData(3, 1), util.getURL());
			
			actions.navigateBack();
			actions.waitAndClick(plansPricing.FreeTrial_toggle());
			actions.waitAndClick(plansPricing.getFreeTrial_SelfEmployed());
			actions.verificationPoint(Utilities.getCellData(4, 1), util.getURL());
			
			}
			
			
			Log.info("----------------The Test Case Passed----------------");
			
			return "Pass";
			
		}catch(Exception e){
			Log.error("************Test case Failed**********");
			ErrorHandling.handleExceptions(e);
		return "Fail";
		}catch(AssertionError e){
			Log.error("************Test case Failed**********");
			ErrorHandling.handleAssertionError(e);
		return "Fail";
	
	}
	}
	
}
